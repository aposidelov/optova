/**
 * This functions are used on user-view and user-edit page
 */

$(document).ready(function() {
    //Create sidebar sticky
    stickyElement("acecrew-profile-tabs", "scroller-anchor");
});
